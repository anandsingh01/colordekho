<div class="container"style="width: 100%;">
    <div class="col-sm-12">
        <div class="row">
            <ul class="top-menu top-menu-left"style="color: white;font-weight: bold;">
{{--                Jan,26,2023--}}
                {{ date('M d, Y') }}
                <a href="https://twitter.com/24x7livekannada"style="padding-left: 9px;">
                    <img src="https://24x7livekannada.com/wp-content/uploads/2022/04/twitter.png"style="width: 22px;"></a>
                <a href="https://www.facebook.com/BMG24x7LiveIndia/">
                    <img src="https://24x7livekannada.com/wp-content/uploads/2022/04/facebook.png"style="width: 22px;"></a>
                <a href="https://www.youtube.com/channel/UCCmAyPWbSfDO46n0qWn3zAQ/videos">
                    <img src="https://24x7livekannada.com/wp-content/uploads/2022/04/youtube.png"style="width: 22px;"></a>
                <a href="https://www.instagram.com/24x7liveindia">
                    <img src="https://24x7livekannada.com/wp-content/uploads/2022/04/instagram.png"style="width: 22px;"></a>
{{--                <div class="jsx-3390231725 nhtranding">--}}
{{--                    <b>Trending Topics :</b>--}}

{{--                    <a href="SPORTS.html" class="jsx-3390231725"style="color: white;">Sports</a>--}}
{{--                    <a href="POLITICS.html" class="jsx-3390231725"style="color: white;">Politics</a>&nbsp;&nbsp;--}}
{{--                    <a href="MORE/ENVIRONMENT.html" class="jsx-3390231725"style="color: white;">Cinema</a>&nbsp;--}}
{{--                    <a href="SPORTS.html" class="jsx-3390231725"style="color: white;">IPL 2022</a>--}}
{{--                </div>--}}
            </ul>
            <ul class="top-menu top-menu-right">
                <li>
                    <form>
                        <select name="list" id="list" accesskey="target"style="
                                 color: white;background: #ec1e28;font-weight: bold;
                                 ">
                            <option value='none' selected>Select your language</option>
                            <option value="{{url('/')}}">English</option>
                            <option value="https://24x7livekannada.com/">Kannada</option>
                            <option value="https://24x7livetv.com/">Hindi</option>
                        </select>
                        <input type=button value="Go" onclick="goToNewPage()" style="color: white;background: #ec1e28;/* height: 37px; */padding-top: 0px; />
                           </form>
                        </li>
                        <li>
                        <a href="https://www.youtube.com/channel/UCCmAyPWbSfDO46n0qWn3zAQ">
                    </form>
                </li>
                <li> <a href="https://www.youtube.com/channel/UCCmAyPWbSfDO46n0qWn3zAQ"><img src="../24x7livekannada.com/wp-content/uploads/2022/03/tv.png" ></a></li>
            </ul>
        </div>
    </div>
</div>
