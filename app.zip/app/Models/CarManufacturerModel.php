<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CarManufacturerModel extends Model
{
    use HasFactory;

    protected $table = 'car_manufacturer_models';
}
