// Demo 10 Js file
$(document).ready(function () {
    'use strict';
});