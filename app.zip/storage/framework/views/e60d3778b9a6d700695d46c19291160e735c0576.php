<?php $getCommonSetting = getCommonSetting();?>
<div class="navbar-brand">
    <button class="btn-menu ls-toggle-btn" type="button"><i class="zmdi zmdi-menu"></i></button>
    <a href=""><img src="<?php echo e(asset(''.$getCommonSetting->logo_header)); ?>" alt="<?php echo e($getCommonSetting->site_title); ?>"></a>
</div>
<div class="menu">
    <ul class="list">

        <li><a href="<?php echo e(url('admin/dashboard')); ?>" class=" waves-effect waves-block">
                <i class="zmdi zmdi-book-image"></i><span>Dashboard</span></a></li>

        <li><a href="javascript:void(0);" class="menu-toggle waves-effect waves-block">
                <i class="zmdi zmdi-apps"></i><span>Add Banner</span></a>
            <ul class="ml-menu">
                <li><a href="<?php echo e(url('admin/all-banner')); ?>"><span>All Banner</span></a></li>
                <li><a href="<?php echo e(url('admin/add-banner')); ?>"><span>Add Banner</span></a></li>
            </ul>
        </li>

        <li><a href="javascript:void(0);" class="menu-toggle waves-effect waves-block">
                <i class="zmdi zmdi-apps"></i>
                <span>Cars</span></a>
            <ul class="ml-menu">
                <li><a href="<?php echo e(url('admin/all-cars')); ?>"><span>Cars Manufacture</span></a></li>
                <li><a href="<?php echo e(url('admin/all-cars-color')); ?>"><span>All Cars Colors</span></a></li>
                <li><a href="<?php echo e(url('admin/all-cars-variations')); ?>"><span>All Cars Variations</span></a></li>
            </ul>
        </li>

        <li><a href="javascript:void(0);" class="menu-toggle waves-effect waves-block">
                <i class="zmdi zmdi-apps"></i>
                <span>Bikes</span></a>
            <ul class="ml-menu">
                <li><a href="<?php echo e(url('admin/all-bikes')); ?>"><span>Bikes Manufacture</span></a></li>
                <li><a href="<?php echo e(url('admin/all-bikes-color')); ?>"><span>All Bikes Colors</span></a></li>
                <li><a href="<?php echo e(url('admin/all-bikes-variations')); ?>"><span>All Bikes Variations</span></a></li>
            </ul>
        </li>


        







        
        
        
        
        
        
        
        









        <li class="<?php echo e(strpos($_SERVER['REQUEST_URI'], "products") ? 'active' : ''); ?>

            || <?php echo e(strpos($_SERVER['REQUEST_URI'], "product") ? 'active' : ''); ?>

            || <?php echo e(strpos($_SERVER['REQUEST_URI'], "attributes") ? 'active' : ''); ?>

            "><a href="javascript:void(0);" class="menu-toggle"><i class="zmdi zmdi-shopping-cart"></i><span>Products</span></a>
            <ul class="ml-menu">
                <li class="<?php echo e(request()->is('add-products') ? 'active' : ''); ?>"><a href="<?php echo e(url('admin/add-products')); ?>">Add Products</a></li>
                <li class="<?php echo e(request()->is('all-products') ? 'active' : ''); ?>"><a href="<?php echo e(url('admin/all-products')); ?>">All Products</a></li>
            </ul>
        </li>
        
        
        
        
        
        
        
        












        <li><a href="javascript:void(0);" class="menu-toggle waves-effect waves-block">
                <i class="zmdi zmdi-apps"></i><span>Orders</span></a>
            <ul class="ml-menu">
                <li><a href="<?php echo e(url('admin/all-orders')); ?>" class=" waves-effect waves-block"><span>All Orders</span></a></li>
                                <li><a href="<?php echo e(url('admin/all-post?type=all-posts')); ?>" class=" waves-effect waves-block"><span>Posts</span></a></li>

            </ul>
        </li>


















        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        

        
        
        
        
        
        
        
        
        

        
        <li><a href="<?php echo e(url('admin/common-settings')); ?>" class=" waves-effect waves-block"><i class="zmdi zmdi-book-image"></i><span>Common Settings</span></a></li>
        <li><a href="<?php echo e(url('admin/all-users')); ?>" class=" waves-effect waves-block"><i class="zmdi zmdi-book-image"></i><span>Users</span></a></li>

    </ul>
</div>
<?php /**PATH H:\xampp\htdocs\colourdekho\resources\views/inc/admin/left-sidebar.blade.php ENDPATH**/ ?>